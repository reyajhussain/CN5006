import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Core car-park service (business rules).
 * - Holds in-memory state of authorised cars and active stays.
 * - Enforces rules: authorisation, no duplicate entry, capacity limit, etc.
 * - Persists every change to disk via DiskStore (write-through).
 *
 * Extension hooks for Part 2:
 *   - onEntered(Stay s)
 *   - onExited(Stay s)
 * These are called after a successful enter/exit and are no-ops in Part 1.
 * In Part 2, you can add receipts, pricing, or audit logging by overriding/expanding these.
 */
public class CarPark {

    private final int capacity;
    private final DiskStore store;

    // In-memory state (fast lookups by plate)
    private final Map<String, Car> authorised = new HashMap<>();
    private final Map<String, Stay> inside    = new HashMap<>();

    public CarPark(int capacity, DiskStore store) throws IOException {
        if (capacity < 1) throw new IllegalArgumentException("Capacity must be positive.");
        this.capacity = capacity;
        this.store = store;
        store.ensureFiles();
        loadFromDisk();
    }

    /** Loads CSV data into memory. */
    private void loadFromDisk() throws IOException {
        authorised.clear();
        inside.clear();

        for (String line : store.readDataLines(store.registeredPath())) {
            Car c = Car.fromCsv(line);
            authorised.put(c.getPlate(), c);
        }
        for (String line : store.readDataLines(store.parkedPath())) {
            Stay s = Stay.fromCsv(line);
            inside.put(s.getPlate(), s);
        }
    }

    /** Saves authorised list to file (sorted by plate). */
    private void saveRegistered() throws IOException {
        List<String> rows = authorised.values().stream()
                .sorted(Comparator.comparing(Car::getPlate))
                .map(Car::toCsv)
                .toList();
        store.writeWithHeader(store.registeredPath(), store.registeredHeader(), rows);
    }

    /** Saves inside list to file (sorted by entry asc). */
    private void saveParked() throws IOException {
        List<String> rows = inside.values().stream()
                .sorted(Comparator.comparing(Stay::getEntry))
                .map(Stay::toCsv)
                .toList();
        store.writeWithHeader(store.parkedPath(), store.parkedHeader(), rows);
    }

    // ---------- Queries ----------
    public int  getCapacity() { return capacity; }
    public int  getOccupied() { return inside.size(); }
    public int  getFree()     { return capacity - getOccupied(); }
    public boolean isFull()   { return getOccupied() >= capacity; }

    public boolean isAuthorised(String plate) { return authorised.containsKey(Car.normalisePlate(plate)); }
    public boolean isInside(String plate)     { return inside.containsKey(Car.normalisePlate(plate)); }

    public List<Car>  viewRegistered() { return authorised.values().stream().sorted(Comparator.comparing(Car::getPlate)).toList(); }
    public List<Stay> viewParked()     { return inside.values().stream().sorted(Comparator.comparing(Stay::getEntry)).toList(); }

    // ---------- Admin (authorisation) ----------
    public void register(String plate, String owner) throws IOException {
        String p = Car.normalisePlate(plate);
        if (authorised.containsKey(p)) throw new IllegalStateException("Vehicle already authorised: " + p);
        authorised.put(p, new Car(p, owner));
        saveRegistered();
    }

    public void unregister(String plate) throws IOException {
        String p = Car.normalisePlate(plate);
        if (inside.containsKey(p)) throw new IllegalStateException("Vehicle is inside; exit before unregistering.");
        if (authorised.remove(p) == null) throw new IllegalStateException("Vehicle is not authorised: " + p);
        saveRegistered();
    }

    // ---------- Gate operations ----------
    public void enter(String plate) throws IOException {
        String p = Car.normalisePlate(plate);
        if (!authorised.containsKey(p)) throw new IllegalStateException("Not authorised: " + p);
        if (inside.containsKey(p))       throw new IllegalStateException("Already inside: " + p);
        if (isFull())                    throw new IllegalStateException("Car park is full.");

        Stay s = new Stay(p, LocalDateTime.now());
        inside.put(p, s);
        saveParked();

        // Part 2 hook: e.g., append to audit log, print entry slip
        onEntered(s);
    }

    /** Removes a car from 'inside' and returns the Stay for further processing (e.g., receipts). */
    public Stay exit(String plate) throws IOException {
        String p = Car.normalisePlate(plate);
        Stay s = inside.remove(p);
        if (s == null) throw new IllegalStateException("Vehicle is not currently parked: " + p);
        saveParked();

        // Part 2 hook: e.g., compute fee, print receipt, update daily report
        onExited(s);
        return s;
    }

    // ---------- Extension hooks (no-ops in Part 1) ----------
    protected void onEntered(Stay s) { /* noop (Part 1) */ }
    protected void onExited(Stay s)  { /* noop (Part 1) */ }
}
