import java.io.IOException;
import java.util.List;
import java.util.Scanner;

/**
 * Entry point and console menu for the CN5004 Part 1 application.
 * Project/App name: CarParkPart1 (matches the brief for continuity into Part 2).
 */
public class CarParkPart1 {

    private static final Scanner IN = new Scanner(System.in);

    public static void main(String[] args) {
        DiskStore store = new DiskStore(Config.REGISTERED_CSV, Config.PARKED_CSV);

        CarPark park;
        try {
            park = new CarPark(Config.CAPACITY, store);
        } catch (IOException e) {
            System.err.println("Failed to initialise storage: " + e.getMessage());
            return;
        }

        // Main loop
        while (true) {
            printHeader(park);
            printMenu();
            String choice = prompt("Choose");
            try {
                switch (choice) {
                    case "1": actionRegister(park); break;
                    case "2": actionUnregister(park); break;
                    case "3": actionViewRegistered(park); break;
                    case "4": actionEnter(park); break;
                    case "5": actionExit(park); break;
                    case "6": actionViewParked(park); break;
                    case "7": actionCheck(park); break;
                    case "0":
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid option. Please select 0–7.");
                }
            } catch (Exception ex) {
                System.out.println("ERROR: " + ex.getMessage());
            }
        }
    }

    // ---------- UI helpers ----------
    private static void printHeader(CarPark park) {
        System.out.println();
        System.out.println("=== CAR PARK PART 1 (Text-Based) ===");
        System.out.println("Capacity: " + park.getCapacity()
                + " | Occupied: " + park.getOccupied()
                + " | Free: " + park.getFree());
    }

    private static void printMenu() {
        System.out.println("1) Register vehicle");
        System.out.println("2) Unregister vehicle");
        System.out.println("3) List registered vehicles");
        System.out.println("4) Vehicle ENTER");
        System.out.println("5) Vehicle EXIT");
        System.out.println("6) List parked vehicles");
        System.out.println("7) Check authorisation/status");
        System.out.println("0) Quit");
    }

    private static String prompt(String label) {
        System.out.print(label + ": ");
        return IN.nextLine().trim();
    }

    // ---------- Actions ----------
    private static void actionRegister(CarPark park) throws IOException {
        String plate = prompt("Plate (e.g., KA01AB1234)").toUpperCase();
        String owner = prompt("Owner name");
        park.register(plate, owner);
        System.out.println("Registered " + plate + " for " + owner + ".");
    }

    private static void actionUnregister(CarPark park) throws IOException {
        String plate = prompt("Plate to remove").toUpperCase();
        park.unregister(plate);
        System.out.println("Unregistered " + plate + ".");
    }

    private static void actionViewRegistered(CarPark park) {
        List<Car> list = park.viewRegistered();
        if (list.isEmpty()) {
            System.out.println("(No authorised vehicles yet.)");
            return;
        }
        System.out.println("-- Authorised Vehicles --");
        for (Car c : list) System.out.println(" • " + c);
    }

    private static void actionEnter(CarPark park) throws IOException {
        String plate = prompt("Plate entering").toUpperCase();
        park.enter(plate);
        System.out.println("Vehicle " + plate + " entered.");
    }

    private static void actionExit(CarPark park) throws IOException {
        String plate = prompt("Plate exiting").toUpperCase();
        var s = park.exit(plate);
        System.out.println("Vehicle " + s.getPlate() + " exited (was parked since " + s.getEntry() + ").");
    }

    private static void actionViewParked(CarPark park) {
        var list = park.viewParked();
        if (list.isEmpty()) {
            System.out.println("(No vehicles currently parked.)");
            return;
        }
        System.out.println("-- Parked Vehicles --");
        for (var s : list) System.out.println(" • " + s);
    }

    private static void actionCheck(CarPark park) {
        String plate = prompt("Plate to check").toUpperCase();
        boolean auth = park.isAuthorised(plate);
        boolean inside = park.isInside(plate);
        System.out.println("Authorised: " + (auth ? "YES" : "NO"));
        System.out.println("Currently parked: " + (inside ? "YES" : "NO"));
    }
}
