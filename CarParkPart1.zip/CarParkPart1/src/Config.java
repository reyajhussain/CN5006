/**
 * Centralised configuration for Part 1 (and a smooth handover to Part 2).
 * Change capacity or file paths here only; the rest of the code will follow.
 */
public final class Config {
    private Config() {} // static-only

    public static final int CAPACITY = 10;

    // CSV file names (relative to project working directory)
    public static final String REGISTERED_CSV = "registered.csv";
    public static final String PARKED_CSV     = "parked.csv";
}
