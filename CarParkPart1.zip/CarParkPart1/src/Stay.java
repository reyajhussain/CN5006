import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Domain entity representing a car currently parked inside the lot.
 * Stores the plate and the entry timestamp.
 */
public class Stay {

    private final String plate;           // Normalised plate (uppercase)
    private final LocalDateTime entry;    // Entry instant

    public static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public Stay(String rawPlate, LocalDateTime entry) {
        if (rawPlate == null || rawPlate.trim().isEmpty()) {
            throw new IllegalArgumentException("Plate is required.");
        }
        if (entry == null) {
            throw new IllegalArgumentException("Entry time is required.");
        }
        this.plate = Car.normalisePlate(rawPlate);
        this.entry = entry;
    }

    /** CSV factory: expects "PLATE,YYYY-MM-DDThh:mm:ss". */
    public static Stay fromCsv(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length < 2) throw new IllegalArgumentException("Bad parked.csv row: " + line);
        return new Stay(parts[0], LocalDateTime.parse(parts[1], ISO));
    }

    /** Serialises to "PLATE,YYYY-MM-DDThh:mm:ss". */
    public String toCsv() { return plate + "," + entry.format(ISO); }

    public String getPlate() { return plate; }
    public LocalDateTime getEntry() { return entry; }

    @Override public String toString() { return plate + " since " + entry.format(ISO); }
}
