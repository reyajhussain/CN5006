import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility for reading/writing CSV files with a header line.
 * - Creates files on first use with headers.
 * - Skips header automatically when reading.
 */
public class DiskStore {

    private final Path registeredCsv;
    private final Path parkedCsv;

    // Self-describing headers for markers/Part 2
    private static final String HDR_REGISTERED = "PLATE,OWNER";
    private static final String HDR_PARKED     = "PLATE,ENTRY_ISO";

    public DiskStore(String registeredFile, String parkedFile) {
        this.registeredCsv = Paths.get(registeredFile);
        this.parkedCsv = Paths.get(parkedFile);
    }

    /** Ensures that both CSV files exist with headers. */
    public void ensureFiles() throws IOException {
        ensureFile(registeredCsv, HDR_REGISTERED);
        ensureFile(parkedCsv, HDR_PARKED);
    }

    private void ensureFile(Path p, String header) throws IOException {
        if (Files.notExists(p)) {
            Files.createFile(p);
            Files.write(p, List.of(header), StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        }
    }

    /** Reads all data lines (skips header). */
    public List<String> readDataLines(Path file) throws IOException {
        List<String> all = Files.readAllLines(file, StandardCharsets.UTF_8);
        List<String> data = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            if (i == 0) continue; // skip header
            String line = all.get(i).trim();
            if (!line.isEmpty()) data.add(line);
        }
        return data;
    }

    /** Writes header + data rows (overwrites file). */
    public void writeWithHeader(Path file, String header, List<String> rows) throws IOException {
        List<String> out = new ArrayList<>(1 + rows.size());
        out.add(header);
        out.addAll(rows);
        Files.write(file, out, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
    }

    // Accessors for paths & headers
    public Path registeredPath()     { return registeredCsv; }
    public Path parkedPath()         { return parkedCsv; }
    public String registeredHeader() { return HDR_REGISTERED; }
    public String parkedHeader()     { return HDR_PARKED; }
}
