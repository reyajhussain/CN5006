/**
 * Domain entity representing an authorised vehicle.
 * Immutable: plate and owner are set once via constructor.
 */
public class Car {

    private final String plate;  // Normalised uppercase plate (key)
    private final String owner;  // Owner's name as supplied (trimmed)

    public Car(String rawPlate, String rawOwner) {
        if (rawPlate == null || rawPlate.trim().isEmpty()) {
            throw new IllegalArgumentException("Plate is required.");
        }
        if (rawOwner == null || rawOwner.trim().isEmpty()) {
            throw new IllegalArgumentException("Owner is required.");
        }
        this.plate = normalisePlate(rawPlate);
        this.owner = rawOwner.trim();
    }

    /** CSV factory: expects "PLATE,OWNER" (header is handled by DiskStore). */
    public static Car fromCsv(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length < 2) throw new IllegalArgumentException("Bad registered.csv row: " + line);
        return new Car(parts[0], parts[1]);
    }

    /** Serialises to "PLATE,OWNER". */
    public String toCsv() { return plate + "," + owner; }

    public String getPlate() { return plate; }
    public String getOwner() { return owner; }

    /** Normalises plate: trim + uppercase. */
    public static String normalisePlate(String s) { return s.trim().toUpperCase(); }

    @Override public String toString() { return plate + " (" + owner + ")"; }

    // Business equality by plate (unique key)
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car)) return false;
        return plate.equals(((Car) o).plate);
    }
    @Override public int hashCode() { return plate.hashCode(); }
}
